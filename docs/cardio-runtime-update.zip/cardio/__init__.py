"""CardioAgent local research workstation."""
__version__ = "2.4.1"
